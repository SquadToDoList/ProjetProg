package com.example.todolist;

import android.os.Bundle;

//-------------------------------------------------------------Class-Objet-Activité---------------------------------------------------------------------------------------------------
//Utilisé comme modele pour faire les lignes du listView
public class Activity {
    private String nom;
    private String nbJours;
    private String Importance;
    private int date;

    //-------------------------------------------------------------Constructeur-----------------------------------------------------

    Activity(String nom, String Importance, int date,String nbJours){
        this.nom = nom;
        this.nbJours = nbJours;
        this.Importance = Importance;
        this.date = date;
    }

    //-------------------------------------------------------------------------------------------------------------------------------

    //----------------------------------------------------------------Methodes-------------------------------------------------------

    public String GetString() {
        String s = "";

        s = nom;
        s += ";" + Importance;
        s += ";" + date;
        s += ";" + nbJours;

        return s;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNbJours() { return nbJours; }

    public void setNbJours(String nbJours) { this.nbJours = nbJours; }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getImportance() {
        return Importance;
    }

    public void setImportance(String importance) {
        Importance = importance;
    }
    //-----------------------------------------------------------------------------------------------------------------------------
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------