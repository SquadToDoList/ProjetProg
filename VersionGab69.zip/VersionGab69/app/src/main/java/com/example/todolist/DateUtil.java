package com.example.todolist;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import static java.util.Calendar.DATE;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.YEAR;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author couturre
 */
public class DateUtil {
    /**
     * Quick hack to get the days that are left until the day selected
     * @param joursTotal As Long .
     * @return The amount of days left.
     */
    public static long daysLeft(long joursTotal){


        Date now = Calendar.getInstance().getTime();
        Calendar a = getCalendar(now);
        int temp1 = ((a.get(YEAR)-2020)*365);
        int temp2 = a.get(MONTH)*31;
        int temp3 = a.get(DAY_OF_MONTH);
        int joursAujourdhui = temp1 + temp2 + temp3;
        return joursTotal - joursAujourdhui;
    }


    /**
     * https://stackoverflow.com/questions/7906301/how-can-i-find-the-number-of-years-between-two-dates
     * @param date The date use to make a Calendar
     * @return The Calendar corresponding to the date send in parameter.
     */
    private static Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance(Locale.US);
        cal.setTime(date);
        return cal;
    }
}
