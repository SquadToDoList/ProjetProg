package com.example.todolist;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
public class PageModify extends MainActivity {
    private Button changeButton;
    private Button DeleteButton;
    private Button cancelButton;
    private RadioButton RadioFaible;
    private RadioButton RadioMoyen;
    private RadioButton RadioElevee;
    private CalendarView MyCalendar;
    private android.widget.RadioGroup RadioGroup;
    public String importance;
    public Button bouttonImportance;
    public EditText editTextTextPersonName;
    //------------------------------------------------------À-la-création----------------------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_modify);

        editTextTextPersonName = findViewById(R.id.editTextTextPersonName);
        changeButton = findViewById(R.id.changeButton);
        DeleteButton = findViewById(R.id.deleteButton);
        cancelButton = findViewById(R.id.cancelButton);
        RadioFaible = findViewById(R.id.radioButton4);
        RadioMoyen = findViewById(R.id.radioButton5);
        RadioElevee = findViewById(R.id.radioButton6);
        MyCalendar = findViewById(R.id.calendarView);
        RadioGroup = findViewById(R.id.radioGroup);
        bouttonImportance = findViewById(R.id.buttonImportance);

        importance = "faible";
        if(importanceActivite.equals("Moyen"))
        {
            RadioFaible.setChecked(false);
            RadioElevee.setChecked(false);
            importance = "Moyen";
        }
        else if(importanceActivite.equals("Elevee"))
        {
            RadioFaible.setChecked(false);
            RadioMoyen.setChecked(false);
            importance = "Élevée";
        }
        editTextTextPersonName.setText(nomActivite);

        RadioFaible.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioMoyen.setChecked(false);
                RadioElevee.setChecked(false);
                importance = getString(R.string.impoRadioFaible);
                //bouttonImportance.setTextColor(Color.GREEN);
            }
        });
        RadioMoyen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioFaible.setChecked(false);
                RadioElevee.setChecked(false);
                importance = getString(R.string.impoRadioMoyen);
                // bouttonImportance.setTextColor(Color.YELLOW);
            }
        });
        RadioElevee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioFaible.setChecked(false);
                RadioMoyen.setChecked(false);
                importance = getString(R.string.impoRadioElevee);
                //bouttonImportance.setTextColor(Color.RED);
            }
        });

        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addLine(view);
                line.remove(lineActivite);
                save();
            }
        });

        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                line.remove(lineActivite);
                finish();
                Reload();
                save();

            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        MyCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month,
                                            int dayOfMonth) {
                String curDate = String.valueOf(dayOfMonth);
                int temp1 = (year-2020)*365;
                int temp2 = month*31;
                int temp3 = dayOfMonth;
                joursTotal = (long)temp1 + temp2 + temp3;
            }
        });

    }

    //-----------------------------------------------------------------------------------------------------------------------------

    //------------------------------------Fonction-pour-modifier-une-ligne-dans-ListView-------------------------------------------

    private void addLine(View view)
    {
        EditText input = findViewById(R.id.editTextTextPersonName);
        String itemText = input.getText().toString();
        long joursRestant = (DateUtil.daysLeft(joursTotal));
        if(!(itemText.equals("")))
        {
            NewLine(itemText, importance, MyCalendar.getDateTextAppearance(), Long.toString(joursRestant));
            finish();
        }
        else{
            Toast.makeText(getApplicationContext(), "Please enter text..", Toast.LENGTH_LONG).show();
        }
    }
    //-----------------------------------------------------------------------------------------------------------------------------
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------