package com.example.todolist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.ArrayList;

import java.io.*;
import java.util.Collections;

//-----------------------------------------------------------------------------Main-Activity------------------------------------------------------------------------------
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    public static ArrayList<Activity> line = new ArrayList<>();
    private static final String FILE_NAME = "ListViewSave.txt";
    public static String nomActivite;
    public static String importanceActivite;
    public static int dateActivite;
    public static int lineActivite;
    public static String nbJoursActivité;
    public static long joursTotal;
    ListView lvActivity;
    private static boolean firstLoad = true;

    //----------------------------------------À-la-création------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lvActivity = findViewById(R.id.lvActivity);


        ActivityAdapter adapter = new ActivityAdapter(this, line);
        lvActivity.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        setUpListViewListener();

        load();

    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------------------Créer-un-writer------------------------------------------

    private void writeToFile(String data, Context context) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("Exception", "File write failed: " + e.toString());
        }
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------------------Créer-un-reader------------------------------------------

    private String readFromFile(Context context) {

        String ret = "";

        try {
            InputStream inputStream = context.openFileInput(FILE_NAME);

            if ( inputStream != null ) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String receiveString = "";
                StringBuilder stringBuilder = new StringBuilder();

                while ( (receiveString = bufferedReader.readLine()) != null ) {
                    stringBuilder.append("\n").append(receiveString);
                }

                inputStream.close();
                ret = stringBuilder.toString();
            }
        }
        catch (FileNotFoundException e) {
            Log.e("login activity", "File not found: " + e.toString());
        } catch (IOException e) {
            Log.e("login activity", "Can not read file: " + e.toString());
        }

        return ret;
    }

    //-------------------------------------------------------------------------------------------------




    //------------------------------Fonction-pour-écrire-dans-le-fichier----------------------------------

    public void save()
    {
        String s = "";
        String t = "";
        int size = line.size();

        for (int i = 0; i < size; i++) {
            t = line.get(i).GetString();

            if (t.length() > 0)
            {
                s += t + "\n";
            }
        }

        writeToFile(s, this);
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------Fonction-pour-lire-dans-le-fichier--------------------------------

    public void load()
    {
        if (firstLoad) {

            String fileLines = readFromFile(this);

            if (fileLines.length() > 0) {

                String[] Lines = fileLines.split("\n");
                String[] Line;

                for (int i = 0; i < Lines.length; i++) {
                    if(Lines[i].length() > 0) {
                        Line = Lines[i].split(";");
                        if(Line.length > 0) {
                            NewLine(Line[0], Line[1], Integer.parseInt(Line[2]), "2");
                        }
                    }
                }
            }
        }
        firstLoad = false;
    }

    //-------------------------------------------------------------------------------------------------





    //------------------------------------Ajouter-une-ligne-à-ListView----------------------------------

   public void NewLine(String name, String importance, int date, String nbJours) {
        line.add(new Activity(name, importance, date, nbJours));
        Reload();
        save();
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------------Rafraichir-l'activité------------------------------------

    public void Reload(){
        Intent refresh = new Intent(this, MainActivity.class);
        startActivity(refresh);
        this.finish();
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------Savoir-sur-quelle-ligne-on-click----------------------------------

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String day = parent.getItemAtPosition(position).toString();
        lineActivite = position;
    }

    //-------------------------------------------------------------------------------------------------




    //----------------------------------------Activity-Adapter--------------------------------------------

    class ActivityAdapter extends ArrayAdapter<Activity> {
        ActivityAdapter(Context context, ArrayList<Activity> line) {
            super(context, R.layout.activity, line);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ActivityWrapper wrapper;

            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.activity, null);
                wrapper = new ActivityWrapper(convertView);
                convertView.setTag(wrapper);
            } else
                wrapper = (ActivityWrapper) convertView.getTag();

            wrapper.setActivity(getItem(position));

            return convertView;
        }
    }

    //-------------------------------------------------------------------------------------------------




    //------------------------------------------Activity-Wrapper----------------------------------------

    class ActivityWrapper {
        private TextView name = null;
        private Button importance = null;
        private View activity = null;
        private Button nbJours = null;

        ActivityWrapper(View activity) {
            this.activity = activity;
        }

        public TextView getName() {
            if (name == null)
                name = (TextView) activity.findViewById(R.id.textViewJour);
            return name;
        }

        public Button getImpo() {
            if (importance == null)
                importance = (Button) activity.findViewById(R.id.buttonImportance);
            return importance;
        }

        public Button getNbJours(){
            if(nbJours == null)
                nbJours = (Button) activity.findViewById(R.id.buttonNbJours);
            return nbJours;
        }

        public void setActivity(Activity j) {
            getName().setText(j.getNom());
            getImpo().setText(j.getImportance());
            getNbJours().setText(j.getNbJours());
            activity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Toast.makeText(MainActivity.this, j.getNom(), Toast.LENGTH_SHORT).show();
                    nomActivite = j.getNom();
                    importanceActivite = j.getImportance();
                    dateActivite = j.getDate();
                    nbJoursActivité = j.getNbJours();
                    OpenChange();

                }
            });
        }
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------------Lister-pour-ListView---------------------------------------

    private void setUpListViewListener() {
        lvActivity.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
            Context context = getApplicationContext();
            Toast.makeText(context, "Item Removed", Toast.LENGTH_LONG).show();

            line.remove(position);
            Reload();

            return false;
        }
    });
    }

    //-------------------------------------------------------------------------------------------------




    //-----------------------------------Creation-Barre-de-Menu----------------------------------------

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu1, menu);
        return true;
    }

    //-------------------------------------------------------------------------------------------------




    //------------------------------------Pop-up-changement-de-page--------------------------------------

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.addItem:
                Toast.makeText(this, R.string.addActivity, Toast.LENGTH_SHORT).show();
                openAdd();
                return true;
            case R.id.settings:
                Toast.makeText(this, R.string.abouttheApp, Toast.LENGTH_SHORT).show();
                openOption();
                return true;
            default: return super.onOptionsItemSelected(item);
        }
    }

    //-------------------------------------------------------------------------------------------------




    //---------------------------------------Ouvrir-Page-Modifier-----------------------------------------

    public void OpenChange()
    {
        Intent intent = new Intent(this, PageModify.class);
        startActivity(intent);
    }

    //-------------------------------------------------------------------------------------------------




    //----------------------------------------Ouvrir-Page-Option--------------------------------------

    public void openOption()
    {
        Intent intent = new Intent(this, PageOption.class);
        startActivity(intent);
    }

    //-------------------------------------------------------------------------------------------------




    //-----------------------------------------Ouvrir-page-add------------------------------------------

    public void openAdd()
    {
        Intent intent = new Intent(this, PageAdd.class);
        startActivity(intent);
    }

    //-------------------------------------------------------------------------------------------------
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------