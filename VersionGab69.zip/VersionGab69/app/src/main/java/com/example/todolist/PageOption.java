package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//--------------------------------------------------------------------------Page-Option------------------------------------------------------------------------------
public class PageOption extends AppCompatActivity {

    private Button ReturnButton;

    //----------------------------------------------À-la-création----------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_settings);

        ReturnButton = (Button) findViewById(R.id.ReturnButtonOption);

        ReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    //-----------------------------------------------------------------------------------------------------------------------------

}
//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------